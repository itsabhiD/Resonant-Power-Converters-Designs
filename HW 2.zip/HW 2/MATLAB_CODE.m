clc;
clear all;
close all;

% Given values
Im = 4; % Peak current (A)
Vdm = 66.7; % Peak diode voltage (V)
D = 0.6; % Duty cycle
T = 1e-6; % Total time period (s)
fs = 1 / T; % Switching frequency (Hz)
fo = fs; % Fundamental frequency assumption
w = 2 * pi * fs; % Angular frequency (rad/s)
IDm_Io_ratio = 4.5; % Given IDm/Io ratio for D = 0.6
RL_approx = 55; % Approximate RL from previous calculations

% Compute wCRL (Dynamic Calculation)
term1 = 1 - (2 * (pi^2) * (1 - D)^2);
term2 = -cos(2 * pi * D);
numerator = ((2 * pi * (1 - D)) + (sin(2 * pi * D)))^2;
denominator = 1 - cos(2 * pi * D);
wCRL = (1 / (2 * pi)) * (term1 + term2 + (numerator / denominator));

% Calculate phi (ϕ)
phi = atan((1 - cos(2*pi*D)) / (2*pi*(1-D) + sin(2*pi*D))) * (180/pi);

% Calculate Io (Output current)
Io = Im * sind(phi);

% Calculate Vo (Output voltage)
Vo = (Vdm * wCRL)/ (2*phi - pi + 2/tand(phi));

% Calculate RL (Load resistance)
RL = Vo / Io;

% Calculate capacitance C
C = Vo / (Vdm * w * RL * ((2 * phi - pi + 2 / tand(phi)) * (pi/180))); % Convert degrees to radians
C_nF = C * 1e9; % Convert to nF

% Compute IDm
IDm = IDm_Io_ratio * Io;

% Calculate Cp
Cp = (Io * Vo) / (IDm * Vdm);
Cp_nF = Cp * 1e9; % Convert to nF

% Calculate Ri
Ri = (2 * sind(phi) * RL) / (2 * (sind(2 * phi) - 1.5 * cosd(phi)));

% Input parameter: Ci/C ratio
Ci_C_ratio = input('Enter the ratio Ci/C: ');

% Calculate Ci
Ci = Ci_C_ratio * C;
Ci_nF = Ci * 1e9; % Convert to nF

% Calculate M_IR
MIR = sqrt(2) * sind(phi);

% Calculate M_VR
MVR = 1 / MIR;

% Calculate Lf_min
Lf_min = (Vo * D) / (Im * fs); % Using Im as Ir_max
Lf_min_uH = Lf_min * 1e6; % Convert to µH

% Calculate Cf_min
Cf_min = 1 / (4 * pi^2 * fo^2 * Lf_min);
Cf_min_nF = Cf_min * 1e9; % Convert to nF

% Display results
fprintf('Phi (ϕ) = %.2f degrees\n', phi);
fprintf('wCRL = %.4f\n', wCRL);
fprintf('Output Current (Io) = %.2f A\n', Io);
fprintf('Output Voltage (Vo) = %.2f V\n', Vo);
fprintf('Load Resistance (RL) = %.2f Ohms\n', RL);
fprintf('Capacitance C = %.2f nF\n', C_nF);
fprintf('Parallel Capacitance Cp = %.2f nF\n', Cp_nF);
fprintf('Input Resistance Ri = %.2f Ohms\n', Ri);
fprintf('Capacitance Ci = %.2f nF\n', Ci_nF);
fprintf('MIR = %.2f\n', MIR);
fprintf('MVR = %.2f\n', MVR);
fprintf('Minimum Filter Inductance (Lf_min) = %.2f µH\n', Lf_min_uH);
fprintf('Minimum Filter Capacitance (Cf_min) = %.2f nF\n', Cf_min_nF);
